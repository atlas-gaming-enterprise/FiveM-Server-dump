function Global.N_0x5db8010ee71fdef2(p0)
	return _in(0x5DB8010EE71FDEF2, p0, _r)
end
