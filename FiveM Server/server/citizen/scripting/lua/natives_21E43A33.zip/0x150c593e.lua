function Global.SetPoliceRadarBlips(toggle)
	return _in(0x43286D561B72B8BF, toggle)
end
