function Global.NetworkGetPlayerFromGamerHandle(p0)
	return _in(0xCE5F689CF5A0A49D, _ii(p0) --[[ may be optional ]], _r, _ri)
end
