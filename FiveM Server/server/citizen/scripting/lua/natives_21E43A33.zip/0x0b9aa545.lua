function Global.TaskRappelFromHeli(ped, p1)
	return _in(0x09693B0312F91649, ped, p1)
end
