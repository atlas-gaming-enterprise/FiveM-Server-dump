function Global.N_0xdaf80797fc534bec(p0)
	return _in(0xDAF80797FC534BEC, p0)
end
