function Global.N_0x644546ec5287471b()
	return _in(0x644546EC5287471B, _r, _ri)
end
