function Global.N_0x55e86af2712b36a1(p0, p1)
	return _in(0x55E86AF2712B36A1, p0, _ii(p1) --[[ may be optional ]])
end
