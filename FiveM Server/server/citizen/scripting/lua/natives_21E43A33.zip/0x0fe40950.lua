function Global.AssistedMovementRequestRoute(route)
	return _in(0x817268968605947A, _ts(route), _r, _ri)
end
