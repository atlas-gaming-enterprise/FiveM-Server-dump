function Global.OverrideCamSplineMotionBlur(p0, p1, p2, p3)
	return _in(0x7DCF7C708D292D55, p0, p1, p2, p3)
end
