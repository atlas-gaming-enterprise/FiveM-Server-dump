function Global.ArrayValueAddObject(arrayData)
	return _in(0x6889498B3E19C797, _ii(arrayData) --[[ may be optional ]], _r, _ri)
end
