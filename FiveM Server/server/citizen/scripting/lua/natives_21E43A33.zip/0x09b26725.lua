function Global.SetPedHelmet(ped, p1)
	return _in(0x560A43136EB58105, ped, p1)
end
