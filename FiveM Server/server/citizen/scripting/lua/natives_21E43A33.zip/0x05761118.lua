function Global.DoesCutsceneEntityExist(p1)
	return _in(0x499EF20C5DB25C59, _i, p1, _r)
end
