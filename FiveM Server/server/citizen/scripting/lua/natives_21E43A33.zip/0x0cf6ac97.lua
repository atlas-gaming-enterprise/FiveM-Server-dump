function Global.N_0x428baccdf5e26ead(p0, p1)
	return _in(0x428BACCDF5E26EAD, p0, p1)
end
