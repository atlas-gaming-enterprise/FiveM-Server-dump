function Global.PlayEndCreditsMusic(p0)
	return _in(0xCD536C4D33DCC900, p0)
end
