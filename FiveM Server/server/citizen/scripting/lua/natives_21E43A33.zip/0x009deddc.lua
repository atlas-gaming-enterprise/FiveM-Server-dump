function Global.IsPedRunning(ped)
	return _in(0xC5286FFC176F28A2, ped, _r)
end
