function Global.N_0x9aa46badad0e27ed()
	return _in(0x9AA46BADAD0E27ED, _r, _ri)
end
