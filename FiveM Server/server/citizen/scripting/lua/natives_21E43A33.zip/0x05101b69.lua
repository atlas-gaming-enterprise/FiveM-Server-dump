function Global.N_0x551df99658db6ee8(p0, p1, p2)
	return _in(0x551DF99658DB6EE8, p0, p1, p2, _r, _ri)
end
