function Global.N_0xc61b86c9f61eb404(p0)
	return _in(0xC61B86C9F61EB404, p0)
end
