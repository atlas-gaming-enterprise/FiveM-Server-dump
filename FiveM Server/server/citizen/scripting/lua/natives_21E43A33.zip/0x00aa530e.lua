function Global.N_0xb6e6fba95c7324ac(doorHash, p1, p2, p3)
	return _in(0xB6E6FBA95C7324AC, _ch(doorHash), p1, p2, p3)
end
