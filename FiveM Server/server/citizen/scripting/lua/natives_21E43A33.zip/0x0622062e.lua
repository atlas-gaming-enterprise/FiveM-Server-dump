function Global.RemoveDecalsFromObjectFacing(obj, x, y, z)
	return _in(0xA6F6F70FDC6D144C, obj, x, y, z)
end
