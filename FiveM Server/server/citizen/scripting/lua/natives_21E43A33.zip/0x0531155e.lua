function Global.ClearGpsPlayerWaypoint()
	return _in(0xFF4FB7C8CDFA3DA7)
end
