function Global.AddEntityIcon(entity, icon)
	return _in(0x9CD43EEE12BF4DD0, entity, _ts(icon), _r, _ri)
end
