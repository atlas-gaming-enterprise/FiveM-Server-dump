function Global.GetPlayerPed(player)
	return _in(0x43A66C31C68491C0, player, _r, _ri)
end
