function Global.N_0x271401846bd26e92(p0, p1)
	return _in(0x271401846BD26E92, p0, p1)
end
