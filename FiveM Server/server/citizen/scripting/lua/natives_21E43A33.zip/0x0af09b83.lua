function Global.StopAllAlarms(p0)
	return _in(0x2F794A877ADD4C92, p0)
end
