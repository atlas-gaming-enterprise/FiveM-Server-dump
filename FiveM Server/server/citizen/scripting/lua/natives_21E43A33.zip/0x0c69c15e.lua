function Global.N_0x45a83257ed02d9bc()
	return _in(0x45A83257ED02D9BC)
end
