function Global.SetGameplayVehicleHint(p0, p1, p2, p3, p4, p5, p6, p7)
	return _in(0xA2297E18F3E71C2E, p0, p1, p2, p3, p4, p5, p6, p7)
end
