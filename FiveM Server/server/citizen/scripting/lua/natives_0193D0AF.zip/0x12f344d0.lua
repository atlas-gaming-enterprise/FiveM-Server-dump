function Global.SetVehicleDoorControl(vehicle, doorIndex, speed, angle)
	return _in(0xF2BFA0430F0A0FCB, vehicle, doorIndex, speed, angle)
end
