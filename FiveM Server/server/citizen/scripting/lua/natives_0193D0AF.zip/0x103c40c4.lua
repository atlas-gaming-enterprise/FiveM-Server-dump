function Global.N_0x5e203da2ba15d436(p0)
	return _in(0x5E203DA2BA15D436, p0, _r, _ri)
end
