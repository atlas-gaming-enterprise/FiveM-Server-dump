function Global.N_0xc61b86c9f61eb404(toggle)
	return _in(0xC61B86C9F61EB404, toggle)
end
