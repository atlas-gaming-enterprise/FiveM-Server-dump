function Global.N_0x9f5e6bb6b34540da(p0)
	return _in(0x9F5E6BB6B34540DA, p0)
end
