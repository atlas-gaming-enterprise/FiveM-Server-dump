function Global.SetWeatherTypeTransition(weatherType1, weatherType2, percentWeather2)
	return _in(0x578C752848ECFA0C, _ch(weatherType1), _ch(weatherType2), percentWeather2)
end
