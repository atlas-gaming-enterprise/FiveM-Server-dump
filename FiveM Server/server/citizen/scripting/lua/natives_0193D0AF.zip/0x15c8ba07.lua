function Global.N_0xaeab987727c5a8a4(p0)
	return _in(0xAEAB987727C5A8A4, p0, _r)
end
