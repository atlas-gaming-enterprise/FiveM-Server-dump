function Global.GetEntityBoneIndexByName(entity, boneName)
	return _in(0xFB71170B7E76ACBA, entity, _ts(boneName), _r, _ri)
end
