function Global.N_0x737e398138550fff(p0, p1)
	return _in(0x737E398138550FFF, p0, p1)
end
