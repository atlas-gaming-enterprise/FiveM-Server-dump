function Global.SetVehicleCanBreak(vehicle, toggle)
	return _in(0x59BF8C3D52C92F66, vehicle, toggle)
end
