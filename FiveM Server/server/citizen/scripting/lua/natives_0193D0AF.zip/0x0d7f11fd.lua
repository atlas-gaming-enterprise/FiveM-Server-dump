function Global.SetWind(speed)
	return _in(0xAC3A74E8384A9919, speed)
end
