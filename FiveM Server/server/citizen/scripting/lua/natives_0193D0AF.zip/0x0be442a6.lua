function Global.N_0x6d6840cee8845831(action)
	return _in(0x6D6840CEE8845831, _ts(action))
end
