function Global.SetPedArmour(ped, amount)
	return _in(0xCEA04D83135264CC, ped, amount)
end
