function Global.N_0x3d3d8b3be5a83d35()
	return _in(0x3D3D8B3BE5A83D35, _r, _ri)
end
