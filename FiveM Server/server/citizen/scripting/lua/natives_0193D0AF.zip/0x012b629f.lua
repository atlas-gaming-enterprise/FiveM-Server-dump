function Global.ForceRoomForEntity(entity, interiorID, roomHashKey)
	return _in(0x52923C4710DD9907, entity, interiorID, _ch(roomHashKey))
end
