function Global.NetworkSessionEnter(p0, p1, p2, maxPlayers, p4, p5)
	return _in(0x330ED4D05491934F, p0, p1, p2, maxPlayers, p4, p5, _r, _ri)
end
