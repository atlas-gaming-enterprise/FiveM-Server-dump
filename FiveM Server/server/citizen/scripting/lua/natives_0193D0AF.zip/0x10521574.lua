function Global.N_0x53cae13e9b426993(p0)
	return _in(0x53CAE13E9B426993, p0)
end
