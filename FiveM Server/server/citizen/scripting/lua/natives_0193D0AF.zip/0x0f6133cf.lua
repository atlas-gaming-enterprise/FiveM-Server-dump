function Global.StatGetNumberOfMinutes(statName)
	return _in(0x7583B4BE4C5A41B5, _ch(statName), _r, _ri)
end
