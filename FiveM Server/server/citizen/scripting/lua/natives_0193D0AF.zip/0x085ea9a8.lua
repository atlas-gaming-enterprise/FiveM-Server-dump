function Global.TaskUseMobilePhone(ped, p1)
	return _in(0xBD2A8EC3AF4DE7DB, ped, p1)
end
