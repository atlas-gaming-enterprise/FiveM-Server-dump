function Global.HasPlayerBeenSpottedInStolenVehicle(player)
	return _in(0xD705740BB0A1CF4C, player, _r)
end
