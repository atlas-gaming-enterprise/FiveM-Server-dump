function Global.N_0xaf60e6a2936f982a(p0, p1)
	return _in(0xAF60E6A2936F982A, p0, p1)
end
