function Global.IsSynchronizedSceneLooped(sceneID)
	return _in(0x62522002E0C391BA, sceneID, _r)
end
