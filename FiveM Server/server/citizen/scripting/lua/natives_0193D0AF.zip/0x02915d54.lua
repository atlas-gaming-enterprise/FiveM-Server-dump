function Global.Floor(value)
	return _in(0xF34EE736CF047844, value, _r, _ri)
end
