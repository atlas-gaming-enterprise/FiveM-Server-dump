function Global.StatGetNumberOfSeconds(statName)
	return _in(0x2CE056FF3723F00B, _ch(statName), _r, _ri)
end
