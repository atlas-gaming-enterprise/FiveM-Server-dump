function Global.GetVehicleOwner(vehicle, entity)
	return _in(0x8F5EBAB1F260CFCE, vehicle, _ii(entity) --[[ may be optional ]], _r)
end
