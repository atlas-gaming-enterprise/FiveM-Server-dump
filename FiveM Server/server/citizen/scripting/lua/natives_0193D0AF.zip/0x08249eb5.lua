function Global.RemoveAllPickupsOfType(pickupHash)
	return _in(0x27F9D613092159CF, _ch(pickupHash))
end
