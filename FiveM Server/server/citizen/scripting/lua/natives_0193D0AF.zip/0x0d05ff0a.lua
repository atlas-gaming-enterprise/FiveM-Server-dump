function Global.N_0x855bc38818f6f684()
	return _in(0x855BC38818F6F684, _r)
end
