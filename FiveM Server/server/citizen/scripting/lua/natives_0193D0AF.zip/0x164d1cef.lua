function Global.N_0x2c173ae2bdb9385e(p0)
	return _in(0x2C173AE2BDB9385E, p0, _r, _ri)
end
