function Global.N_0xa51c4b86b71652ae(p0)
	return _in(0xA51C4B86B71652AE, p0)
end
