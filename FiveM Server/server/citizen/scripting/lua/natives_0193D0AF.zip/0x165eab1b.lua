function Global.N_0x88e32db8c1a4aa4b(ped, p1)
	return _in(0x88E32DB8C1A4AA4B, ped, p1)
end
