--- Needs more research. Gets the stat name of a masked int?
-- p4 - Usually one of the following (there may be more that I missed):
-- -----> "_APAPSTAT_INT"
-- -----> "_LRPSTAT_INT"
-- -----> "_NGPSTAT_INT"
-- -----> "_MP_APAPSTAT_INT"
-- -----> "_MP_LRPSTAT_INT"
function Global.N_0x2b4cdca6f07ff3da(index, spStat, charStat, character, section)
	return _in(0x2B4CDCA6F07FF3DA, index, spStat, charStat, character, _ts(section), _r, _ri)
end
