function Global.SetPedChanceOfFiringBlanks(ped, xBias, yBias)
	return _in(0x8378627201D5497D, ped, xBias, yBias)
end
