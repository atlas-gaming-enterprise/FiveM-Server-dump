function Global.N_0x606e4d3e3cccf3eb()
	return _in(0x606E4D3E3CCCF3EB, _r, _ri)
end
