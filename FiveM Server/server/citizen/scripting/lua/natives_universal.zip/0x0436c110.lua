function Global.GetWeaponComponentTypeModel(componentHash)
	return _in(0x0DB57B41EC1DB083, _ch(componentHash), _r, _ri)
end
