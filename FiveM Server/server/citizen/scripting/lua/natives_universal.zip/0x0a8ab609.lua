--- The first parameter is the amount spent which is store in a global when this native is called. The global returns 10. Which is the price for both rides.
-- The last 3 parameters are,
-- 2,0,1 in the am_ferriswheel.c
-- 1,0,1 in the am_rollercoaster.c
function Global.NetworkBuyFairgroundRide(amountSpent, p1, p2, p3)
	return _in(0x8A7B3952DD64D2B5, amountSpent, p1, p2, p3)
end
