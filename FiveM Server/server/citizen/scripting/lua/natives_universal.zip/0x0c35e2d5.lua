function Global.N_0xfcfacd0db9d7a57d(ped, p1)
	return _in(0xFCFACD0DB9D7A57D, ped, p1)
end
