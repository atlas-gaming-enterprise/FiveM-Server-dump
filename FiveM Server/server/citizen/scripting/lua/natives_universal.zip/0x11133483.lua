function Global.N_0xd0ee05fe193646ea()
	return _in(0xD0EE05FE193646EA, _i, _i, _i, _r)
end
