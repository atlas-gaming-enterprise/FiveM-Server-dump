--- Gets the ped for a specified player index.
-- @param playerId The player index, or -1 to get the local player ped.
-- @return The specified player's ped, or 0 if invalid.
function Global.GetPlayerPed(playerId)
	return _in(0x43A66C31C68491C0, playerId, _r, _ri)
end
