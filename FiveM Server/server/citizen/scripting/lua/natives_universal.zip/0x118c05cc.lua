--- AI::TASK_SYNCHRONIZED_SCENE(ped, scene, "creatures@rottweiler@in_vehicle@std_car", "get_in", 1000.0, -8.0, 4, 0, 0x447a0000, 0);
-- Animations List : www.ls-multiplayer.com/dev/index.php?section=3
function Global.TaskSynchronizedScene(ped, scene, animDictionary, animationName, speed, speedMultiplier, duration, flag, playbackRate, p9)
	return _in(0xEEA929141F699854, ped, scene, _ts(animDictionary), _ts(animationName), speed, speedMultiplier, duration, flag, playbackRate, p9)
end
