function Global.SmashVehicleWindow(vehicle, index)
	return _in(0x9E5B5E4D2CCD2259, vehicle, index, _r, _ri)
end
