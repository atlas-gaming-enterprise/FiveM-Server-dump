function Global.N_0xe38cb9d7d39fdbcc(vehicle, x, y, z)
	return _in(0xE38CB9D7D39FDBCC, vehicle, x, y, z)
end
