--- http://gtaforums.com/topic/717612-v-scriptnative-documentation-and-research/?p=1068285912
function Global.N_0x9304881d6f6537ea(hudComponent)
	return _in(0x9304881D6F6537EA, hudComponent)
end
