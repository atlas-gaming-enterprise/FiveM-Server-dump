--- BLR the shit.
function Global.N_0x8b6a4dd0af9ce215(playerType, playerCount)
	return _in(0x8B6A4DD0AF9CE215, playerType, playerCount)
end
