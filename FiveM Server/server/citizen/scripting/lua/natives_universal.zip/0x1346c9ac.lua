function Global.N_0x9a62ec95ae10e011()
	return _in(0x9A62EC95AE10E011, _r, _ri)
end
