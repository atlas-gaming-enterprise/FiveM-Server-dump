function Global.N_0xb2ebe8cbc58b90e9()
	return _in(0xB2EBE8CBC58B90E9, _r, _ri)
end
