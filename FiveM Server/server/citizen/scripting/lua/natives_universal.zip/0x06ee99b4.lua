--- Public Sub detatchTrailer(vh1 As Vehicle)
-- Native.Function.Call(Hash.DETACH_VEHICLE_FROM_TRAILER, vh1)
-- End Sub
function Global.DetachVehicleFromTrailer(vehicle)
	return _in(0x90532EDF0D2BDD86, vehicle)
end
