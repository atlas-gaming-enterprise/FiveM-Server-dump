--- 0 -> up
-- 1 -> lowering down
-- 2 -> down
-- 3 -> raising up
-- enum RoofState
-- {
-- ROOFSTATE_UP = 0;
-- ROOFSTATE_LOWERING,
-- ROOFSTATE_DOWN,
-- ROOFSTATE_RAISING
-- };
function Global.GetConvertibleRoofState(vehicle)
	return _in(0xF8C397922FC03F41, vehicle, _r, _ri)
end
