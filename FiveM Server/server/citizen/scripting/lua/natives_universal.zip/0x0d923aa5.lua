--- 2 calls in the b617d scripts. This line is called 2 times:
-- AUDIO::_031ACB6ABA18C729("RADIO_16_SILVERLAKE", "MIRRORPARK_LOCKED");
-- Note: Another name for RADIO_16_SILVERLAKE is RADIO MIRROR PARK
function Global.N_0x031acb6aba18c729(radioStation, p1)
	return _in(0x031ACB6ABA18C729, _ts(radioStation), _ts(p1))
end
