function Global.N_0xbbf327ded94e4deb(p0)
	return _in(0xBBF327DED94E4DEB, _ts(p0))
end
