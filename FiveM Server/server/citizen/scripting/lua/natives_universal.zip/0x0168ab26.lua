--- console hash: 0x71CDD52F
function Global.SetVehicleHudSpecialAbilityBarActive(vehicle, active)
	return _in(0x99C82F8A139F3E4E, vehicle, active)
end
