--- yoga.ysc
-- if (PED::IS_PED_WEARING_HELMET(iParam0) && PED::_0x451294E859ECC018(iParam0) != -1)
-- {
-- *uParam2 = PED::_0x451294E859ECC018(iParam0);
-- *uParam3 = PED::_0x9D728C1E12BF5518(iParam0);
-- }
function Global.N_0x451294e859ecc018(p0)
	return _in(0x451294E859ECC018, p0, _r)
end
