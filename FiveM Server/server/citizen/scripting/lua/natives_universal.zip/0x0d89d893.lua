function Global.NetworkClearPropertyId()
	return _in(0xC2B82527CA77053E)
end
