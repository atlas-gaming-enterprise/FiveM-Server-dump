--- Only documented...
function Global.N_0x729e3401f0430686(animDict, animName)
	return _in(0x729E3401F0430686, _ts(animDict), _ts(animName), _r)
end
