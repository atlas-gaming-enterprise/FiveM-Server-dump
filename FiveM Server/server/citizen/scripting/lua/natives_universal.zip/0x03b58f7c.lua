function Global.N_0x31125fd509d9043f(p0)
	return _in(0x31125FD509D9043F, _ii(p0) --[[ may be optional ]])
end
