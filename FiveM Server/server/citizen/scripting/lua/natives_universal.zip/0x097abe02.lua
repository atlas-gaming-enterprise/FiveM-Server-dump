function Global.GetJackTarget(ped)
	return _in(0x5486A79D9FBD342D, ped, _r, _ri)
end
