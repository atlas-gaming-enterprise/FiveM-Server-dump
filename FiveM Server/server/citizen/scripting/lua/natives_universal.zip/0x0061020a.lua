--- Sets how much the crane on the tow truck is raised, where 0.0 is fully lowered and 1.0 is fully raised.
function Global.SetTowTruckCraneHeight(towTruck, height)
	return _in(0xFE54B92A344583CA, towTruck, height)
end
