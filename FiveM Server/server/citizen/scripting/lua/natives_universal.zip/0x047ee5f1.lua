--- only works on some fx's
function Global.SetParticleFxNonLoopedColour(r, g, b)
	return _in(0x26143A59EF48B262, r, g, b)
end
