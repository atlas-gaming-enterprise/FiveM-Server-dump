--- Returns true if the wheels are custom wheels
function Global.GetVehicleModVariation(vehicle, modType)
	return _in(0xB3924ECD70E095DC, vehicle, modType, _r)
end
