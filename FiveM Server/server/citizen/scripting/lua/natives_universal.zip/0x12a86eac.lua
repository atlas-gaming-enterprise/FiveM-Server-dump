function Global.Leaderboards2ReadByRadius(p1)
	return _in(0x5CE587FB5A42C8C4, _i, p1, _i, _r)
end
