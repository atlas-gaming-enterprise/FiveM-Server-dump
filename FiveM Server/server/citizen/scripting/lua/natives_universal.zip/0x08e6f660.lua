--- what does this native do?
-- bool IsEntitySomething(Entity entity)
-- {
-- auto addr = getScriptHandleBaseAddress(entity);
-- printf("addr: 0x%X \n", addr);
-- if (addr)
-- {
-- DWORD flag = *(DWORD *)(addr + 0x48D);
-- printf("flag: 0x%X \n", flag);
-- return ((flag & (1 << 3)) != 0) || ((flag & (1 << 30)) != 0);
-- }
-- return false;
-- }
-- wot ?
function Global.N_0x3910051ccecdb00c(entity, toggle)
	return _in(0x3910051CCECDB00C, entity, toggle)
end
