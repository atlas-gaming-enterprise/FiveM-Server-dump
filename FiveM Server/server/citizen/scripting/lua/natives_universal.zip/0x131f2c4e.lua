--- Forces footstep tracks on all surfaces.
function Global.SetForcePedFootstepsTracks(toggle)
	return _in(0xAEEDAD1420C65CC0, toggle)
end
